package ddw.mobile.finalproject.ma02_20180970;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class AllContactsActivity extends AppCompatActivity {

    ListView lvContacts = null;
    ContactDBHelper helper;
    Cursor cursor;
    //SimpleCursorAdapter adapter;
    MyCursorAdapter adapter;

    ContactDto dto;
    private ArrayList<ContactDto> contactList;

    EditText editText;

    final int UPDATE_CODE = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_contacts);

        editText = findViewById(R.id.editSearch_my);

        lvContacts = (ListView)findViewById(R.id.lvContacts);

        helper = new ContactDBHelper(this);
        contactList = new ArrayList<ContactDto>();

        //MyCursorAdapter 객체 생성
        adapter = new MyCursorAdapter(this, R.layout.listview_trip, null);
        lvContacts.setAdapter(adapter);

        //삭제
        lvContacts.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, final long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(AllContactsActivity.this);
                builder.setTitle("여행기록 삭제")
                        .setMessage("여행기록을 삭제하시겠습니까?")
                        .setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                SQLiteDatabase db = helper.getWritableDatabase();
                                String whereClause = ContactDBHelper.COL_ID + "=?";
                                String[] whereArgs = new String[]{String.valueOf(id)};

                                db.delete(ContactDBHelper.TABLE_NAME, whereClause, whereArgs);

                                query();
                                adapter.notifyDataSetChanged();
                                helper.close();
                            }
                        })
                        .setNegativeButton("취소", null)
                        .setCancelable(false)
                        .show();

                return true;
            }
        });

        //수정
        lvContacts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Intent intent = new Intent(AllContactsActivity.this, UpdateContactActivity.class);
                intent.putExtra("id", id);
                startActivityForResult(intent, UPDATE_CODE);
            }
        });
    }

    public void onClick(View v) {
        Intent intent = null;

        switch (v.getId()) {
            case R.id.btnSearch_my:/*
                String string = editText.getText().toString();
                SQLiteDatabase db = helper.getWritableDatabase();

                String selection = ContactDBHelper.COL_PLACE + "=?";
                String[] selectArgs = new String[] {string};

                Cursor cursor = db.query(ContactDBHelper.TABLE_NAME, null, selection, selectArgs, null, null, null, null);

                while (cursor.moveToNext()) {
                    dto = new ContactDto();
                    dto.set_id(cursor.getInt(cursor.getColumnIndex(ContactDBHelper.COL_ID)));
                    dto.setPlace(cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_PLACE)));
                    dto.setDate(cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_DATE)));
                    dto.setDays(cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_DAYS)));

                    contactList.add(dto);
                }
                adapter.notifyDataSetChanged();
                cursor.close();*/
                break;
            case R.id.btnAddNewContact:
                intent = new Intent (this, InsertContactActivity.class);
                break;
            case R.id.btnBack:
                finish();
                break;
        }
        if (intent != null) startActivity(intent);
    }


    public void query() {
        //      DB에서 데이터를 읽어와 Adapter에 설정
        SQLiteDatabase db = helper.getReadableDatabase();
        cursor = db.rawQuery("select * from " + ContactDBHelper.TABLE_NAME, null);

        adapter.changeCursor(cursor);
    }


    public void Search(String place) {

    }
    @Override
    protected void onResume() {
        super.onResume();
        query();

        helper.close();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //cursor 사용 종료
        if (cursor != null)
            cursor.close();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == UPDATE_CODE) {    // UpdateActivity 호출 후 결과 확인
            switch (resultCode) {
                case RESULT_OK:
                    Toast.makeText(this, "수정 완료", Toast.LENGTH_SHORT).show();
                    break;
                case RESULT_CANCELED:
                    Toast.makeText(this, "수정 취소", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    }
}