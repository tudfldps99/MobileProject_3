package ddw.mobile.finalproject.ma02_20180970;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;

public class UpdateContactActivity extends AppCompatActivity {

    EditText etPlace;
    //EditText etDate;
    EditText etDays;

    ContactDBHelper helper;
    long id;
    ContactDto dto;

    Button btn;
    CalendarView calView;
    TextView tvYear, tvMonth, tvDay;
    int selectYear, selectMonth, selectDay;
    String text;

    Button btnSharing;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_contact);

        etPlace = findViewById(R.id.etPlace);
        //etDate = findViewById(R.id.etDate);
        etDays = findViewById(R.id.etDays);

        btn = findViewById(R.id.button);
        calView = findViewById(R.id.calendarView);
        tvYear = findViewById(R.id.tvYear);
        tvMonth = findViewById(R.id.tvMonth);
        tvDay = findViewById(R.id.tvDay);

        btnSharing = findViewById(R.id.btnSharing);

        helper = new ContactDBHelper(this);

        id = getIntent().getLongExtra("id", 0);

        SQLiteDatabase db = helper.getReadableDatabase();

        String selection = ContactDBHelper.COL_ID + "=?";
        String[] selectArgs = new String[]{ String.valueOf(id) };

        Cursor cursor = db.query(ContactDBHelper.TABLE_NAME, null, selection, selectArgs, null, null, null, null);

        while (cursor.moveToNext()) {
            dto = new ContactDto();
            dto.set_id(cursor.getInt(cursor.getColumnIndex(ContactDBHelper.COL_ID)));
            dto.setPlace(cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_PLACE)));
            dto.setDate(cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_DATE)));
            dto.setDays(cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_DAYS)));
        }

        etPlace.setText(dto.getPlace());
        //etDate.setText(dto.getDate());
        etDays.setText(dto.getDays());

        //calendar 위젯 사용.
        calView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                selectYear = year;
                selectMonth = month + 1;
                selectDay = dayOfMonth;

                String y = String.valueOf(selectYear);
                String m = String.valueOf(selectMonth);
                String d = String.valueOf(selectDay);

                if (selectMonth <= 9) {
                    m = "0" + m;
                }
                if (selectDay <= 9) {
                    d = "0" + d;
                }

                text = y + m + d;
            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvYear.setText(Integer.toString(selectYear));
                tvMonth.setText(Integer.toString(selectMonth));
                tvDay.setText(Integer.toString(selectDay));
            }
        });

        btnSharing.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent Sharing_intent = new Intent(Intent.ACTION_SEND);
                Sharing_intent.setType("text/plain");
                String Sharing_Message = "<다녀온 여행지 공유> \n" +
                        "여행 장소: " + dto.getPlace() + "\n" +
                        " / 여행 날짜(출발일): " + dto.getDate() + "\n" +
                        " / 여행일 수: " + dto.getDays();
                Sharing_intent.putExtra(Intent.EXTRA_TEXT, Sharing_Message);

                Intent Sharing = Intent.createChooser(Sharing_intent, "공유하기");
                startActivity(Sharing);
            }
        });

        cursor.close();
        helper.close();
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnUpdateContact:
                String place = etPlace.getText().toString();
                String date = text;
                String days = etDays.getText().toString();

                ContentValues values = new ContentValues();
                values.put(ContactDBHelper.COL_PLACE, place);
                values.put(ContactDBHelper.COL_DATE, date);
                values.put(ContactDBHelper.COL_DAYS, days);

                SQLiteDatabase db = helper.getWritableDatabase();

                String whereClause = ContactDBHelper.COL_ID + "=?";
                String[] whereArgs = new String[]{ String.valueOf(id) };

                db.update(ContactDBHelper.TABLE_NAME, values, whereClause, whereArgs);

                Intent resultIntent = new Intent();
                resultIntent.putExtra("id", id);
                setResult(RESULT_OK, resultIntent);

                finish();
                break;
            case R.id.btnUpdateContactClose:
                setResult(RESULT_CANCELED);
                finish();
                break;
        }
    }
}