package ddw.mobile.finalproject.ma02_20180970;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyCursorAdapter extends CursorAdapter {

    LayoutInflater inflater;
    int layout;


    public MyCursorAdapter(Context context, int layout, Cursor c) {
        super(context, c, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        this.inflater = (LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        this.layout = layout;
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        View view = inflater.inflate(layout, parent, false);

        //ViewHolder 적용
        ViewHolder holder = new ViewHolder();
        view.setTag(holder);

        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {

        //ViewHoler 적용
        ViewHolder holder = (ViewHolder) view.getTag();

        if (holder.tvContactPlace == null) { //채워넣는 역할
            //holder.tvImage = view.findViewById(R.id.ivImage);
            holder.tvContactPlace = view.findViewById(R.id.tvTitle);
            holder.tvContactDate = view.findViewById(R.id.tvContactDate);
            holder.tvContactDays = view.findViewById(R.id.tvContactDays);
        }

        //holder.tvImage.setId(cursor.getInt(cursor.getColumnIndex(ContactDBHelper.COL_IMG)));
        holder.tvContactPlace.setText(cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_PLACE)));
        holder.tvContactDate.setText(cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_DATE)));
        holder.tvContactDays.setText(cursor.getString(cursor.getColumnIndex(ContactDBHelper.COL_DAYS)));

    }

    static class ViewHolder {

        public ViewHolder() {
            tvImage = null;
            tvContactPlace = null;
            tvContactDate = null;
            tvContactDays = null;
        }

        ImageView tvImage;
        TextView tvContactPlace;
        TextView tvContactDate;
        TextView tvContactDays;
    }
}
