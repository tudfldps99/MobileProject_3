package ddw.mobile.finalproject.ma02_20180970;

import android.text.Html;
import android.text.Spanned;

import java.io.Serializable;

public class ContactDto implements Serializable {

    private long _id;
    int img;
    private String place;   //여행지
    private String date;    //여행 날짜
    private String days;    //여행 일수
    private byte[] image;

    public long get_id() {
        return _id;
    }
    public void set_id(long _id) {
        this._id = _id;
    }

    public int getImg() {
        return img;
    }
    public void setImg(int img) {
        this.img = img;
    }

    public String getPlace() {
        return place;
    }
    public void setPlace(String place) {
        this.place = place;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getDays() {
        return days;
    }
    public void setDays(String days) {
        this.days = days;
    }
    public byte[] getImage() {
        return image;
    }
    public void setImage(byte[] image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return _id + ". " + place + " - " + date + " (" + days + ")";
    }
}
