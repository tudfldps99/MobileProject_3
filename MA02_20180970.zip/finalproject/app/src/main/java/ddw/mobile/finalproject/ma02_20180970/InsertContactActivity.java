package ddw.mobile.finalproject.ma02_20180970;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class InsertContactActivity extends AppCompatActivity {

    ImageView addImg;
    EditText etPlace;
    //EditText etDate;
    EditText etDays;

    ContactDBHelper helper;

    Button btn;
    CalendarView calView;
    TextView tvYear, tvMonth, tvDay;
    int selectYear, selectMonth, selectDay;
    String text;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_contact);

        addImg = findViewById(R.id.imageView);
        etPlace = findViewById(R.id.etPlace);
        //etDate = findViewById(R.id.etDate);
        etDays = findViewById(R.id.etDays);

        btn = findViewById(R.id.button);
        calView = findViewById(R.id.calendarView);
        tvYear = findViewById(R.id.tvYear);
        tvMonth = findViewById(R.id.tvMonth);
        tvDay = findViewById(R.id.tvDay);

        helper = new ContactDBHelper(this);

        //calendar 위젯 사용.
        calView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                selectYear = year;
                selectMonth = month + 1;
                selectDay = dayOfMonth;

                String y = String.valueOf(selectYear);
                String m = String.valueOf(selectMonth);
                String d = String.valueOf(selectDay);

                if (selectMonth <= 9) {
                    m = "0" + m;
                }
                if (selectDay <= 9) {
                    d = "0" + d;
                }

                text = y + m + d;
            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvYear.setText(Integer.toString(selectYear));
                tvMonth.setText(Integer.toString(selectMonth));
                tvDay.setText(Integer.toString(selectDay));
            }
        });
    }

    public void onClick (View v) {
        switch (v.getId()) {
            case R.id.btnAddNewContact:
                SQLiteDatabase db = helper.getWritableDatabase();

                ContentValues values = new ContentValues();
                values.put(ContactDBHelper.COL_IMG, addImg.getId());
                values.put(ContactDBHelper.COL_PLACE, etPlace.getText().toString());
                values.put(ContactDBHelper.COL_DATE, text);
                values.put(ContactDBHelper.COL_DAYS, etDays.getText().toString());

                db.insert(ContactDBHelper.TABLE_NAME, null, values);

                helper.close();
                finish();
                break;
            case R.id.btnAddNewContactClose:
                finish();
                break;
        }
    }
}